package ExerEmSala5_6_2025;

public enum Situacao {
    A_VENDA,
    RESERVADO,
    VENDIDO
}
