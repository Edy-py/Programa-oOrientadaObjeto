package ExerEmSala5_6_2025;


import ExerEmSala5_6_2025.Funcoes.Cabessalho;

public class Principal {
    public static void main(String[] args) {

       Cabessalho cabessalho = new Cabessalho("Programacao Orientada a Objeto","05/06/2025","Exercício em sala","Marcio");
       cabessalho.imprimir();

       InitiObjetos.iniciar();

    }
}