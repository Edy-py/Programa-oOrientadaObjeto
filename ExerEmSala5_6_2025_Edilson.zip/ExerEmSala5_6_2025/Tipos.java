package ExerEmSala5_6_2025;

public enum Tipos {
    CASA,
    APARTAMENTO,
    LOTE

}
