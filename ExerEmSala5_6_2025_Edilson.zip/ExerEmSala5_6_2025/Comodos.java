package ExerEmSala5_6_2025;

public class Comodos {
    String nome;
    int quantidade;

    public Comodos(String nome, int quantidade){
        this.nome = nome;
        this.quantidade = quantidade;
    }
}
